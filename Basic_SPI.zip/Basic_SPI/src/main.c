
#include "mgos_timers.h"
#include "SPI_init.h"
//#include "CC2500_VAL.h"
#include "CC2500_REG.h"

/***********************************
 * prototypes 
 **********************************/
static void CC2500_sendPacket(void *arg);
/************************************
 * Global Variables & Macros
 * *********************************/

#define Data_Rate 250
#define Frequency 2440
#define Channel 50
#define Antenna 1
#define Packet_lenght 50
uint8_t radioPktBuffer[Packet_lenght];
uint32_t currentMillis3 = 0;

/************************************
 * Main function
 * *********************************/
enum mgos_app_init_result mgos_app_init(void)
{

  mgos_gpio_setup_output(RF_SWITCH_A, 0);
  mgos_gpio_setup_output(RF_SWITCH_B, 0);
  mgos_gpio_setup_input(GDO0, 0);
  
  Read_Config_Regs();
  select_antenna(Antenna);
  select_channel(Channel);
  select_data(Data_Rate);
  select_freq(Frequency);
  init_CC2500();
  for (uint8_t i = 0; i <= 10; i++)
  {
    radioPktBuffer[i] = i;
  }
  //CC2500_sendPacket(10);
  mgos_set_timer(1000 /* ms */, MGOS_TIMER_REPEAT,CC2500_sendPacket , NULL);
  LOG(LL_INFO, ("init_CC2500 Done !"));
  
  return MGOS_APP_INIT_SUCCESS;
}

static void CC2500_sendPacket(void *arg)
{
  uint8_t pktlen = 10;
  radioPktBuffer[0] = pktlen; // Length byte

  SendStrobe(CC2500_SIDLE);
  SendStrobe(CC2500_SFTX); // flush tx FIFO

  SendStrobe(0x7F); // 3f for single at a time 7f for burst
  
  for (uint8_t i = 0; i <= pktlen; i++)
  {
    SendStrobe(radioPktBuffer[i]);
    //LOG(LL_INFO, ("Sending %d", radioPktBuffer[i]));
  }
  SendStrobe(CC2500_STX); //Send data in tx fifo wirelessly
  //SendStrobe(CC2500_STX); //Send data in tx fifo wirelessly
  for (uint8_t i = 0; i <= pktlen; i++)
  {
    //SendStrobe(radioPktBuffer[i]);
    LOG(LL_INFO, ("Sending %d", radioPktBuffer[i]));
  }
  

  // Serial.print("\n wait till GPO0 is LOW");
  currentMillis3 = mgos_uptime();
  while ((!mgos_gpio_read(GDO0)) && (mgos_uptime() - currentMillis3 < 10)); 
   LOG(LL_INFO, ("sent %d",mgos_gpio_read(GDO0)));
  // wait till data get transmitted
  //Serial.print("\n wait for GPIO gets HIGH");
  currentMillis3 = mgos_uptime();
  while ((mgos_gpio_read(GDO0)) && (mgos_uptime() - currentMillis3 < 10));
  LOG(LL_INFO, ("sent %d",mgos_gpio_read(GDO0)));
 (void) arg;


 
}