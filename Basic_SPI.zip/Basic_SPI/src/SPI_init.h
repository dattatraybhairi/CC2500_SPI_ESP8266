#ifndef SPI_init
#define SPI_init
/***************************************
 * include header files 
 * ************************************/

#include "mgos.h"
#include "mgos_spi.h"
#include <stdint.h>
#include "CC2500_REG.h"

/*************************************
 * Declare Variables Here : 
 ************************************/
#define RF_SWITCH_A 00 //D3
#define RF_SWITCH_B 02 //D4
#define GDO0 05        //D1

/************************************
 * Functions Prototypes 
 ***********************************/

void ReadReg(uint8_t data);
void Read_Config_Regs(void);
void WriteReg(uint8_t regadd, uint8_t value);
void init_CC2500(void);
void SendStrobe(uint8_t data);
void select_freq(int recv);
void select_data(int recv);
void select_antenna(uint8_t ant_sel);
void select_channel(uint8_t channel_Num);




#endif
