#include "SPI_init.h"
#include "CC2500_VAL.h"
int PACKET_LENGTH = 0;
uint8_t RSSI_offset;

void ReadReg(uint8_t data)
{
  struct mgos_spi *spi;
  spi = mgos_spi_get_global();
  if (spi == NULL)
  {
    LOG(LL_ERROR, ("SPI is not configured, make sure spi.enable is true"));
    return;
  }
  uint8_t rx_data = 0;
  data = data + 0x80;
  struct mgos_spi_txn txn = {
      .cs = 0, /* Use CS0 line as configured by cs0_gpio */
      .mode = 0,
      .freq = 4000000,
  };
  /* Half-duplex, command/response transaction setup */
  /* Transmit 1 byte from tx_data. */
  txn.hd.tx_len = sizeof(data);
  txn.hd.tx_data = &data;
  /* No dummy bytes necessary. */
  txn.hd.dummy_len = 0;
  /* Receive 3 bytes into rx_data. */
  txn.hd.rx_len = 1;
  txn.hd.rx_data = &rx_data;
  if (!mgos_spi_run_txn(spi, false /* full_duplex */, &txn))
  {
    LOG(LL_ERROR, ("SPI transaction failed"));
    return;
  }
  LOG(LL_INFO,
      (" SPI REG: %02x", rx_data));
}

void WriteReg(uint8_t regadd, uint8_t value)
{
  struct mgos_spi *spi;
  spi = mgos_spi_get_global(); // initializing the spi comm getting all spi access
  if (spi == NULL)
  {
    LOG(LL_ERROR, ("SPI is not configured, make sure spi.enable is true"));
    return;
  }
  uint8_t data[2] = {regadd, value}; //data to be written
  struct mgos_spi_txn txn = {
      .cs = 0,         /* Use CS0 line as configured by cs0_gpio */
      .mode = 0,       //mode of SPI
      .freq = 4000000, //frequency of comm
  };
  txn.hd.tx_len = sizeof(data);
  txn.hd.tx_data = &data;
  if (!mgos_spi_run_txn(spi, false /* full_duplex */, &txn))
  {
    LOG(LL_ERROR, ("SPI transaction failed"));
    return;
  }
}

void SendStrobe(uint8_t data)
{
  struct mgos_spi *spi;
  spi = mgos_spi_get_global();
  if (spi == NULL)
  {
    LOG(LL_ERROR, ("SPI is not configured, make sure spi.enable is true"));
    return;
  }
  struct mgos_spi_txn txn = {
      .cs = 0, /* Use CS0 line as configured by cs0_gpio */
      .mode = 0,
      .freq = 10000000,
  };
  txn.hd.tx_len = sizeof(data);
  txn.hd.tx_data = &data;
  if (!mgos_spi_run_txn(spi, false /* full_duplex */, &txn))
  {
    LOG(LL_ERROR, ("SPI transaction failed"));
    return;
  }
}

void Read_Config_Regs(void)
{

  ReadReg(REG_IOCFG2);
  ReadReg(REG_IOCFG1);
  ReadReg(REG_IOCFG0);
  ReadReg(REG_FIFOTHR);
  ReadReg(REG_SYNC1);
  ReadReg(REG_SYNC0);
  ReadReg(REG_PKTLEN);
  ReadReg(REG_PKTCTRL1);
  ReadReg(REG_PKTCTRL0);
  ReadReg(REG_ADDR);
  ReadReg(REG_CHANNR);
  ReadReg(REG_FSCTRL1);
  ReadReg(REG_FSCTRL0);
  ReadReg(REG_FREQ2);
  ReadReg(REG_FREQ1);
  ReadReg(REG_FREQ0);
  ReadReg(REG_MDMCFG4);
  ReadReg(REG_MDMCFG3);
  ReadReg(REG_MDMCFG2);
  ReadReg(REG_MDMCFG1);
  ReadReg(REG_MDMCFG0);
  ReadReg(REG_DEVIATN);
  ReadReg(REG_MCSM2);
  ReadReg(REG_MCSM1);
  ReadReg(REG_MCSM0);
  ReadReg(REG_BSCFG);
  ReadReg(REG_AGCCTRL2);
  ReadReg(REG_AGCCTRL1);
}

void init_CC2500(void)
{
  /*recv = 2; // for 2460 MHz
  select_freq();
  recv = 2; // for 250k data rate
  select_data();*/

  VAL_CHANNR = 0x03;          // Channel number.
  VAL_MCSM1 = 0x30;           // Main Radio Control State Machine configuration.
  VAL_IOCFG2 = 0x0B;          // GDO2 output pin configuration.
  VAL_IOCFG0 = 0x06;          // GDO0 output pin configuration. Sync word.
  VAL_PKTCTRL1 = 0x04;        // Packet automation control.
  VAL_PKTCTRL0 = 0x45;        // Packet automation control. Data whitening on. //05
  VAL_ADDR = 0x00;            // Device address. Not used.
  VAL_PKTLEN = PACKET_LENGTH; // Packet length.

  SendStrobe(CC2500_SRES);

  WriteReg(REG_IOCFG2, VAL_IOCFG2);
  WriteReg(REG_IOCFG0, VAL_IOCFG0);
  WriteReg(REG_IOCFG1, VAL_IOCFG1);

  WriteReg(REG_FIFOTHR, VAL_FIFOTHR);
  WriteReg(REG_SYNC1, VAL_SYNC1);
  WriteReg(REG_SYNC0, VAL_SYNC0);
  WriteReg(REG_PKTLEN, VAL_PKTLEN);
  WriteReg(REG_PKTCTRL1, VAL_PKTCTRL1);
  WriteReg(REG_PKTCTRL0, VAL_PKTCTRL0);

  WriteReg(REG_ADDR, VAL_ADDR);
  WriteReg(REG_CHANNR, VAL_CHANNR);
  WriteReg(REG_FSCTRL1, VAL_FSCTRL1);
  WriteReg(REG_FSCTRL0, VAL_FSCTRL0);
  WriteReg(REG_FREQ2, VAL_FREQ2);
  WriteReg(REG_FREQ1, VAL_FREQ1);
  WriteReg(REG_FREQ0, VAL_FREQ0);
  WriteReg(REG_MDMCFG4, VAL_MDMCFG4);
  WriteReg(REG_MDMCFG3, VAL_MDMCFG3);
  WriteReg(REG_MDMCFG2, VAL_MDMCFG2);
  WriteReg(REG_MDMCFG1, VAL_MDMCFG1);
  WriteReg(REG_MDMCFG0, VAL_MDMCFG0);
  WriteReg(REG_DEVIATN, VAL_DEVIATN);
  WriteReg(REG_MCSM2, VAL_MCSM2);
  WriteReg(REG_MCSM1, VAL_MCSM1);
  WriteReg(REG_MCSM0, VAL_MCSM0);
  WriteReg(REG_FOCCFG, VAL_FOCCFG);
  WriteReg(REG_BSCFG, VAL_BSCFG);
  WriteReg(REG_AGCCTRL2, VAL_AGCCTRL2);
  WriteReg(REG_AGCCTRL1, VAL_AGCCTRL1);
  WriteReg(REG_AGCCTRL0, VAL_AGCCTRL0);
  WriteReg(REG_WOREVT1, VAL_WOREVT1);
  WriteReg(REG_WOREVT0, VAL_WOREVT0);
  WriteReg(REG_WORCTRL, VAL_WORCTRL);
  WriteReg(REG_FREND1, VAL_FREND1);
  WriteReg(REG_FREND0, VAL_FREND0);
  WriteReg(REG_FSCAL3, VAL_FSCAL3);
  WriteReg(REG_FSCAL2, VAL_FSCAL2);
  WriteReg(REG_FSCAL1, VAL_FSCAL1);
  WriteReg(REG_FSCAL0, VAL_FSCAL0);
  WriteReg(REG_RCCTRL1, VAL_RCCTRL1);
  WriteReg(REG_RCCTRL0, VAL_RCCTRL0);
  WriteReg(REG_FSTEST, VAL_FSTEST);
  WriteReg(REG_PTEST, VAL_PTEST);
  WriteReg(REG_AGCTEST, VAL_AGCTEST);
  WriteReg(REG_TEST2, VAL_TEST2);
  WriteReg(REG_TEST1, VAL_TEST1);
  WriteReg(REG_TEST0, VAL_TEST0);
  WriteReg(CC2500_PATABLE, VAL_PATABLE);
}

void select_freq(int recv)
{
  switch (recv)
  {
  case 2480:
    VAL_FREQ2 = 0x5F; // 2480Mhz
    VAL_FREQ1 = 0x62;
    VAL_FREQ0 = 0x76;
    LOG(LL_INFO, ("Selected Base Frequncy:2480Mhz"));
    break;

  case 2460:
    VAL_FREQ2 = 0x5E; //2460Mhz
    VAL_FREQ1 = 0x9D;
    VAL_FREQ0 = 0x89;
    LOG(LL_INFO, ("Selected Base Frequncy:2460Mhz"));
    break;

  case 2440:
    VAL_FREQ2 = 0x5D; // 2440Mhz
    VAL_FREQ1 = 0xD8;
    VAL_FREQ0 = 0x9D;
    LOG(LL_INFO, ("Selected Base Frequncy:2440Mhz"));
    break;

  case 2420:
    VAL_FREQ2 = 0x5D; // 2420Mhz
    VAL_FREQ1 = 0x13;
    VAL_FREQ0 = 0xB1;
    LOG(LL_INFO, ("Selected Base Frequncy:2420Mhz"));
    break;

  case 2433:
    VAL_FREQ2 = 0x5D; // 2433Mhz
    VAL_FREQ1 = 0x93;
    VAL_FREQ0 = 0xB1;
    LOG(LL_INFO, ("Selected Base Frequncy:2433Mhz"));
    break;

  case 2400:
    VAL_FREQ2 = 0x5C; // 2400.5Mhz
    VAL_FREQ1 = 0x4E;
    VAL_FREQ0 = 0xC3;
    LOG(LL_INFO, ("Selected Base Frequncy:2400Mhz"));
    break;

  default:
    select_freq(1);
  }
}

void select_data(int recv)
{
  switch (recv)
  {
  case 500:             // for 500K baud
    VAL_FSCTRL1 = 0x10; // Frequency synthesizer control.
    VAL_FSCTRL0 = 0x00; // Frequency synthesizer control.
    VAL_MDMCFG4 = 0x0E; // Modem configuration.
    VAL_MDMCFG3 = 0x3B; // Modem configuration.
    VAL_MDMCFG2 = 0x73; // Modem configuration.
    VAL_MDMCFG1 = 0x42; // Modem configuration.
    VAL_MDMCFG0 = 0xF8; // Modem configuration.
    VAL_DEVIATN = 0x00; // Modem deviation setting (when FSK modulation is enabled).
    VAL_FREND1 = 0xB6;  // Front end RX configuration.
    VAL_FREND0 = 0x10;  // Front end RX configuration.
    //VAL_MCSM0    = 0x14;   // Main Radio Control State Machine configuration.
    VAL_MCSM0 = 0x04;
    VAL_FOCCFG = 0x1D;   // Frequency Offset Compensation Configuration.
    VAL_BSCFG = 0x1C;    // Bit synchronization Configuration.
    VAL_AGCCTRL2 = 0xC7; // AGC control.
    VAL_AGCCTRL1 = 0x40; // AGC control.
    VAL_AGCCTRL0 = 0xB2; // AGC control.
    VAL_FSCAL3 = 0xEA;   // Frequency synthesizer calibration.
    VAL_FSCAL2 = 0x0A;   // Frequency synthesizer calibration.
    VAL_FSCAL0 = 0x11;   // Frequency synthesizer calibration.
    VAL_TEST2 = 0x88;    // Various test settings.
    VAL_TEST1 = 0x31;    // Various test settings.
    VAL_TEST0 = 0x0B;    // Various test settings.
    RSSI_offset = 72;
    LOG(LL_INFO, ("Selected Base Data Rate:500Kbits"));
    break;

  case 250: // for 250K baud
    //    VAL_FSCTRL1  = 0x0A;   // Frequency synthesizer control.
    //    VAL_FSCTRL0  = 0x00;   // Frequency synthesizer control.
    //    VAL_MDMCFG4  = 0x2D;   // Modem configuration.
    //    VAL_MDMCFG3  = 0x3B;   // Modem configuration.
    //    VAL_MDMCFG2  = 0x73;   // Modem configuration.
    //    VAL_MDMCFG1  = 0x22;   // Modem configuration.
    //    VAL_MDMCFG0  = 0xF8;   // Modem configuration.
    //    VAL_DEVIATN  = 0x00;   // Modem deviation setting (when FSK modulation is enabled).
    //    VAL_FREND1   = 0xB6;   // Front end RX configuration.
    //    VAL_FREND0   = 0x10;   // Front end RX configuration.
    //    VAL_MCSM0    = 0x14;   // Main Radio Control State Machine configuration.
    //    VAL_FOCCFG   = 0x1D;   // Frequency Offset Compensation Configuration.
    //    VAL_BSCFG    = 0x1C;   // Bit synchronization Configuration.
    //    VAL_AGCCTRL2 = 0xC7;   // AGC control.
    //    VAL_AGCCTRL1 = 0x00;   // AGC control.
    //    VAL_AGCCTRL0 = 0xB2;   // AGC control.
    //    VAL_FSCAL3   = 0xEA;   // Frequency synthesizer calibration.
    //    VAL_FSCAL2   = 0x0A;   // Frequency synthesizer calibration.
    //    VAL_FSCAL0   = 0x11;   // Frequency synthesizer calibration.
    //    VAL_TEST2    = 0x88;   // Various test settings.
    //    VAL_TEST1    = 0x31;   // Various test settings.
    //    VAL_TEST0    = 0x0B;   // Various test settings.
    VAL_FSCTRL1 = 0x0A; // Frequency synthesizer control.
    VAL_FSCTRL0 = 0x00; // Frequency synthesizer control.
    VAL_MDMCFG4 = 0x2D; // Modem configuration.
    VAL_MDMCFG3 = 0x3B; // Modem configuration.
    VAL_MDMCFG2 = 0x73; // Modem configuration.
    VAL_MDMCFG1 = 0x22; // Modem configuration.
    VAL_MDMCFG0 = 0xF8; // Modem configuration.
    VAL_DEVIATN = 0x00; // Modem deviation setting (when FSK modulation is enabled).
    VAL_FREND1 = 0xB6;  // Front end RX configuration.
    VAL_FREND0 = 0x10;  // Front end RX configuration.
    VAL_MCSM0 = 0x14;   // Main Radio Control State Machine configuration.//18
    //VAL_MCSM0    = 0x04;
    VAL_FOCCFG = 0x1D;   // Frequency Offset Compensation Configuration.
    VAL_BSCFG = 0x1C;    // Bit synchronization Configuration.
    VAL_AGCCTRL2 = 0xC7; // AGC control.
    VAL_AGCCTRL1 = 0x00; // AGC control.
    VAL_AGCCTRL0 = 0xB2; // AGC control. //B0
    VAL_FSCAL3 = 0xEA;   // Frequency synthesizer calibration.
    VAL_FSCAL2 = 0x0A;   // Frequency synthesizer calibration.
    VAL_FSCAL0 = 0x11;   // Frequency synthesizer calibration.
    VAL_TEST2 = 0x88;    // Various test settings.
    VAL_TEST1 = 0x31;    // Various test settings.
    VAL_TEST0 = 0x0B;    // Various test settings.
    RSSI_offset = 72;
    LOG(LL_INFO, ("Selected Base Data Rate:250Kbits"));
    break;

  case 10: // for 10K baud

    VAL_FSCTRL1 = 0x08;  // Frequency synthesizer control.
    VAL_FSCTRL0 = 0x00;  // Frequency synthesizer control.
    VAL_MDMCFG4 = 0x78;  // Modem configuration.
    VAL_MDMCFG3 = 0x93;  // Modem configuration.
    VAL_MDMCFG2 = 0x03;  // Modem configuration. // 73 for MSK
    VAL_MDMCFG1 = 0x22;  // Modem configuration.
    VAL_MDMCFG0 = 0xF8;  // Modem configuration.
    VAL_DEVIATN = 0x44;  // Modem deviation setting (when FSK modulation is enabled).
    VAL_FREND1 = 0x56;   // Front end RX configuration.
    VAL_FREND0 = 0x10;   // Front end RX configuration.
    VAL_MCSM0 = 0x14;    // Main Radio Control State Machine configuration.
    VAL_FOCCFG = 0x16;   // Frequency Offset Compensation Configuration.
    VAL_BSCFG = 0x6C;    // Bit synchronization Configuration.
    VAL_AGCCTRL2 = 0x43; // AGC control.
    VAL_AGCCTRL1 = 0x40; // AGC control.
    VAL_AGCCTRL0 = 0x91; // AGC control.
    VAL_FSCAL3 = 0xA9;   // Frequency synthesizer calibration.
    VAL_FSCAL2 = 0x0A;   // Frequency synthesizer calibration.
    VAL_FSCAL0 = 0x11;   // Frequency synthesizer calibration.
    VAL_TEST2 = 0x88;    // Various test settings.
    VAL_TEST1 = 0x31;    // Various test settings.
    VAL_TEST0 = 0x0B;    // Various test settings.
    RSSI_offset = 69;
    LOG(LL_INFO, ("Selected Base Data Rate:10Kbits"));
    break;

  default:
    select_data(250);
  }
}

void select_antenna(uint8_t ant_sel)
{
  if ((ant_sel & 0x01) == 0x01)
    mgos_gpio_write(RF_SWITCH_A, true);
  else
    mgos_gpio_write(RF_SWITCH_A, false);

  if ((ant_sel & 0x02) == 0x02)
    mgos_gpio_write(RF_SWITCH_B, true);
  else
    mgos_gpio_write(RF_SWITCH_B, false);
  LOG(LL_INFO, ("Selected Antenna : %d", ant_sel));
}

void select_channel(uint8_t channel_Num)
{
  WriteReg(REG_CHANNR, channel_Num);
  LOG(LL_INFO, ("Selected Channel: %d ", channel_Num));
}
